﻿using System;

namespace MultiplicationMatrix
{
   public class Program
    {
       public static void Main(string[] args)
        {
            int x, y;

            Console.WriteLine("Введите значение x: ");
            if (!int.TryParse(Console.ReadLine(), out x) || x <= 0)
            {
                Console.WriteLine("Некорректный ввод для x. Пожалуйста, введите положительное целое число.");
                return;
            }

            Console.WriteLine("Введите значение y: ");
            if (!int.TryParse(Console.ReadLine(), out y) || y <= 0)
            {
                Console.WriteLine("Некорректный ввод для y. Пожалуйста, введите положительное целое число.");
                return;
            }

            int[,] matrix = new int[x, y];

            Console.WriteLine("Матрица умножения:");

            for (int i = 0; i < x; i++)
            {
                for (int j = 0; j < y; j++)
                {
                    matrix[i, j] = (i + 1) * (j + 1);
                    Console.Write(matrix[i, j] + " ");
                }
                Console.WriteLine();
            }
        }
    }
}
