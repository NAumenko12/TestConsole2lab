﻿using Microsoft.VisualStudio.TestPlatform.TestHost;
using NUnit.Framework;
using System;
using System.IO;

namespace MatrixMultiplication.Tests
{
    [TestFixture]
    public class Test
    {
        [Test]
        public void TestMatrixMultiplication()
        {
            using (StringWriter sw = new StringWriter())
            {
                Console.SetOut(sw);

                using (StringReader sr = new StringReader("3\n4\n"))
                {
                    Console.SetIn(sr);

                    Program.Main();
                }

                string expectedOutput = "Матрица умножения:\r\n1 2 3 4 \r\n2 4 6 8 \r\n3 6 9 12 \r\n";

                Assert.AreEqual(expectedOutput, sw.ToString());
            }
        }

        [Test]
        public void TestInvalidInput()
        {
            using (StringWriter sw = new StringWriter())
            {
                Console.SetOut(sw);

                using (StringReader sr = new StringReader("-3\n4\n"))
                {
                    Console.SetIn(sr);

                    Program.Main();
                }

                string expectedOutput = "Некорректный ввод. Пожалуйста, введите положительные целые числа.\r\n";

                Assert.AreEqual(expectedOutput, sw.ToString());
            }
        }
    }
}
