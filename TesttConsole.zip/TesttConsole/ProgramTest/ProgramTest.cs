﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;

namespace MultiplicationMatrix.Tests
{
    [TestClass]
    public class ProgramTests
    {
        [TestMethod]
        public void TestValidInput()
        {
            using (var sw = new StringWriter())
            {
                Console.SetOut(sw);

                var input = new StringReader("3\n4\n");
                Console.SetIn(input);

                Program.Main(null);

                var expectedOutput = "Введите значение x: \r\nВведите значение y: \r\nМатрица умножения:\r\n1 2 3 \r\n2 4 6 \r\n3 6 9 \r\n4 8 12 \r\n";

                Assert.AreEqual(expectedOutput, sw.ToString());
            }
        }

        [TestMethod]
        public void TestInvalidInput()
        {
            using (var sw = new StringWriter())
            {
                Console.SetOut(sw);

                var input = new StringReader("-3\n4\n");
                Console.SetIn(input);

                Program.Main(null);

                var expectedOutput = "Введите значение x: \r\nНекорректный ввод для x. Пожалуйста, введите положительное целое число.\r\n";

                Assert.AreEqual(expectedOutput, sw.ToString());
            }
        }
    }
}
